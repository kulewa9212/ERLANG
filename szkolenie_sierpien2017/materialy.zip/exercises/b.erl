-module(b).
-export([x/0]).
-vsn(1.0).

x() -> 1.
